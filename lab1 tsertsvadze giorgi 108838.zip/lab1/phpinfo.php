<?php

    phpinfo(); //გამოგვაქვს პჰპს ინფორმაცია
//test
//test2

//last try

?>